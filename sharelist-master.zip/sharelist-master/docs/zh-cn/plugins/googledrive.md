# Google Drive

## GoogleDrive ID
使用分享的文件ID挂载。
```分享的文件ID``` 即是 挂载路径。

## GoogleDrive API
官方API挂载
```挂载路径
//应用ID/root?client_secret=应用机钥&redirect_uri=回调地址&refresh_token=refresh_token   
```
或
```
  /   
```
建议填写```/```，ShareList将自动开启挂载向导，按指示操作即可。  
