# Aliyun Drive

由 [drive.aliyundrive.js](https://github.com/reruin/sharelist/tree/master/plugins/drive.aliyundrive.js) 插件实现。
将```挂载路径留空```，ShareList将自动开启挂载向导，按指示填写refresh_token即可。

?> 如何获取refresh_token？   
![refresh_token？](https://raw.githubusercontent.com/wxy1343/aliyunpan/main/token.png)


