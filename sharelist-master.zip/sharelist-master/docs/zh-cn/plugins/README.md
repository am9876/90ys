# 挂载源

sharelist通过插件支持多种挂载源。从```后台管理```->```虚拟路径```，选择挂载源，输入挂载的名称和挂载路径即可。
![001.png](https://i.loli.net/2020/10/12/DAzubBWSkPGTCEq.png)